console.log("  ``-'   .-+Pwsl}c}7L}L}c}{ll]{]Z%T'.-.-'``  - -'-'`  ' `. '.-'' '.'   ' ''--'-_XPT '  '`' `-\n");
console.log("  .' - ` >6Ef]x}x[}]7}7{lLLc][kPT -`-`'  - ` '' `'  .  `. - `' .` ' - -    .  V9s '`.-'  '`.'\n");
console.log("..`-`. .`<%wsccxc]xL}lc}c[[lLxkSY   '  ` .' `- .-   --' ``.-`.`.'  ''`.`` `.ryEZ<. `'   ' . '\n");
console.log("` - '---.+APy{7[cx{{x]7{]i|v[]ZP1```  '-`.-'` `. .. -`.. .`  ``   ` `   -'!yS6T,`.  '-    -'.\n");
console.log("    -. ``'` >%%t7{Lc{7cc7ll_.'.i]k91  .- . `'' --.` '-` `' `'`' .' ...``--''...Xhx ``. `.  `-\n");
console.log("  ` ' ' . ->PPzlcc7x]}c}L}?+<rxLX6#YYL>'`. ' ' --. ''`-  `  ``'`. .. `  '- '`iAS'`.. -` `  '-\n");
console.log("'' `-`.-' I6$uJFj2njCCujJ2JF2IA%Yl[VEey11TY1Y11YTT1Y1Y111T1TYT1TT1Y1TYTTy2XPn=.'-  .`..- -- -\n");
console.log("  .     .' *v]L]xx}[77}]][]cc]|_. .-<|v[[lLxcl[[[[l]Lc]}cl]LxLl[}lxLlL}xiv;!` '`   . `    ` -\n");
